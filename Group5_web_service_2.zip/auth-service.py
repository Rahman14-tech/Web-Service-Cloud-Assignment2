import datetime
from flask import Flask, abort, redirect, request, jsonify, make_response
# For authentication. We are using the PyJWT library
import jwt
import hashlib

app = Flask(__name__)
def simple_sha256(plain_password: str) -> str:
    return hashlib.sha256(plain_password.encode("utf-8")).hexdigest()
# For simplicity, we are using secret key as constants
# We used https://jwtsecretkeygenerator.com to generate a random secret key
JWT_SECRET = "rk8VXd4obfUfKHNzsAHBgYJlq4UVXJ4L1KxiImZ9Js8"
# For the algorithm, we are using HS256, which is a symmetric signing algorithm that uses the same secret key for both signing and verifying the token.
JWT_ALGO = "HS256"
JWT_EXP_MINUTES = 15

database_of_users = {
    'mulyono': {'pass': simple_sha256('hidupJokowi'), 'token': None},
    'jaden':{'pass': simple_sha256('jaden123'), 'token': None},
    'ali':{'pass': simple_sha256('ali123'), 'token': None},
}


def create_jwt(username: str) -> str:
    now = datetime.datetime.utcnow()
    payload = {
        "sub": username,
        "iat": now,
        "exp": now + datetime.timedelta(minutes=JWT_EXP_MINUTES),
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)
    # If bytes returened, convert into utf-8
    if isinstance(token, bytes):
        token = token.decode("utf-8")
    return token

@app.route("/users",methods = ['GET','POST','PUT','PATCH'])
def users():
    if request.method == "GET":
        return make_response(jsonify({"users_record":database_of_users}), 200)
    if request.method == "POST":
        # Try to get the JSON request
        data = request.get_json()
        # Try to get the username from the JSON request
        if "username" not in data:
            return make_response(jsonify({"msg":"username is missing"}), 400)
        username = data["username"]

        # Try to get the password
        if "password" not in data:
            return make_response(jsonify({"msg":"password is missing"}), 400)
        password = data["password"]

        # If the user already exists, we don't want someone else overwriting their password!
        if username in database_of_users:
            abort(409)
        
        # Add them in the database
        database_of_users[username] = { "pass": simple_sha256(password), "token": None }
        # Done!
        return "success", 200
    elif request.method == "PUT":
        # Try to get the JSON request
        data = request.get_json()
        # Try to get the username, old password and new password
        if "username" not in data:
            return make_response(jsonify({"msg":"username not specified"}), 400)
        username = data["username"]
        if "old-password" not in data:
            return make_response(jsonify({"msg":"old-password not specified"}), 400)
        old_password = data["old-password"]
        if "new-password" not in data:
            return make_response(jsonify({"msg":"new-password not specified"}), 400)
        new_password = data["new-password"]

        # Check if the user exists
        if username not in database_of_users: abort(404)

        # Check if the password is valid
        if database_of_users[username]["pass"] != simple_sha256(old_password): abort(403)

        # Update the password based on the new password
        database_of_users[username]["pass"] = simple_sha256(new_password)
        return make_response(jsonify({"msg":"success"}), 200)
    elif request.method == "PATCH":
        # Try to get the JSON request
        data = request.get_json()
        # Try to get the old username, new username and password
        if "username" not in data:
            return make_response(jsonify({"msg":"username not specified"}), 400)
        username = data["username"]
        if "new-username" not in data:
            return make_response(jsonify({"msg":"new-username not specified"}), 400)
        new_username = data["new-username"]
        if "password" not in data:
            return make_response(jsonify({"msg":"password not specified"}), 400)
        password = data["password"]

        # Check if the user exists
        if username not in database_of_users: return make_response(jsonify({"msg":"username doesn't exist"}), 400)
        # Check if the new-username is used
        if new_username in database_of_users: return make_response(jsonify({"msg":"the new username is already being used"}), 400)

        # Check if the password is valid
        if database_of_users[username]["pass"] != simple_sha256(password): abort(403)

        # Update the password based on the new password
        temp_old_user_data = database_of_users[username]
        database_of_users.pop(username, None)
        database_of_users[new_username] = temp_old_user_data
        return make_response(jsonify({"msg":"success"}), 200)
    
@app.route("/users/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return make_response(jsonify({"message": "username and password required"}), 400)

    # Checking provided credentials against the hardcoded User's dictionary
    if username not in database_of_users or database_of_users[username]["pass"] != simple_sha256(password):
        return make_response(jsonify({"message": "invalid credentials"}), 401)

    token = create_jwt(username)
    database_of_users[username]['token'] = f"Bearer {token}"
    return make_response(jsonify({"token": f"Bearer {token}"}), 200)

if __name__ == "__main__":
    app.run(port=8001, debug=True)